package com.nagarro.productmanagementutility.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

/**
 * The Class UserEntity.
 * 
 */
@Entity
public class UserEntity {

	/** The user name. */
	@Id
	@Column
	private String userName;

	/** The pass word. */
	@Column
	private String passWord;

	/**
	 * Gets the pass word.
	 *
	 * @return the passWord
	 */
	public String getPassWord() {
		return passWord;
	}

	/** The email. */
	@Column
	private String email;

	/** The name. */
	@Column
	private String name;

	/**
	 * Gets the name.
	 *
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * Sets the name.
	 *
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * Gets the email.
	 *
	 * @return the email
	 */
	public String getemail() {
		return email;
	}

	/**
	 * Sets the email.
	 *
	 * @param email the email to set
	 */
	public void setemail(String email) {
		this.email = email;
	}

	/**
	 * Gets the user name.
	 *
	 * @return the userName
	 */
	public String getUserName() {
		return userName;
	}

	/**
	 * Sets the user name.
	 *
	 * @param userName the userName to set
	 */
	public void setUserName(String userName) {
		this.userName = userName;
	}

	/**
	 * Sets the pass word.
	 *
	 * @param passWord the new pass word
	 */
	public void setPassWord(String passWord) {
		this.passWord = passWord;
	}
}
